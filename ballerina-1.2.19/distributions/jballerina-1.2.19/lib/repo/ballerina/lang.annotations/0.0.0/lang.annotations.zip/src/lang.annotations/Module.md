## Module Overview

This module provides predefined annotations and default error type declaration.
