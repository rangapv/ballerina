## Module overview

This module provides utility functions to manipulate the built-in `xml` data type. 
It provides APIs to convert a `json` to an `xml` or convert a `table` to an `xml`.
