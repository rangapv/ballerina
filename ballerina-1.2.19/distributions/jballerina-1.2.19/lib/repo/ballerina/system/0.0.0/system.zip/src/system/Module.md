## Module overview

This module provides functions to retrieve information about the system and the current users of the system. The `system:exec` method creates the `system:Process` object, which can control and obtain information about a Ballerina process.

For information on the operations, which you can perform with the system module, see the below **Functions**.
