## Module Overview

This module provides lang library map operations defined by the language specification 2020R1.
