## Module Overview

This module provides a function to transform the XML content to another XML/HTML/plain text using XSL transformations.

For information on the operations, which you can perform with this module, see the below **Functions**. For examples on the usage of the operations, see the [XSLT Transformation Example](https://ballerina.io/1.2/learn/by-example/xslt-transformation.html).