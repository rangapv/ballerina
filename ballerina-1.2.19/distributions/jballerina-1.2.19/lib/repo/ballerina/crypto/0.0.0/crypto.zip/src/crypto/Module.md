## Module Overview

This module provides the necessary utilities that are required to hash content using different hashing mechanisms and algorithms. 

For information on the operations, which you can perform with this module, see the below **Functions**. For an example on the usage of the operations, see the [Cryptographic Operations Example](https://ballerina.io/1.2/learn/by-example/crypto.html).
