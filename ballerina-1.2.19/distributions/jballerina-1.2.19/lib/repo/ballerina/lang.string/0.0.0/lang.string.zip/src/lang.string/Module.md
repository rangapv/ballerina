## Module Overview

This module provides lang library string operations defined by the language specification 2020R1.
