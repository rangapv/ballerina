## Module overview

This module provides utility functions to manipulate the built-in `string` data type. 
