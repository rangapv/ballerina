## Module Overview

This module provides utility functions to manipulate the built-in `json` data type. It provides APIs to convert an `xml` to a `json` or convert a `table` to a `json`.
