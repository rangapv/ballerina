## Module Overview

This module provides APIs to create new Java array instances, get elements from arrays, set elements, etc. 

For information on the operations, which you can perform with the java.arrays module, see the below **Functions**. For an example on the usage of the operations, see the [Java Arrays Example](https://ballerina.io/1.2/learn/by-example/java-arrays.html).