## Module Overview

This module provides a platform-independent API for working with file paths.

For information on the operations, which you can perform with this module, see the below **Functions**.

* For an example on the usage of the operations, see the [File Path Example](https://ballerina.io/1.2/learn/by-example/filepath.html).
