## Module Overview

This module defines the shape expected from all listeners as defined by the language specification 2020R1.
