## Module Overview

This module provides the necessary utilities, which are required to encode and decode content using different URL encoding mechanisms and algorithms.

For information on the operations, which you can perform with this module, see the below **Functions**.
